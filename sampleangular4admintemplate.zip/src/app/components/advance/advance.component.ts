import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advance',
  template: '<router-outlet><spinner></spinner></router-outlet>'
})
export class AdvanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
